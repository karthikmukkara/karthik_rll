import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Book } from 'src/app/entity/Book';
import { BookService } from 'src/app/service/book.service';

@Component({
  selector: 'app-edit-book',
  templateUrl: './edit-book.component.html',
  styleUrls: ['./edit-book.component.css']
})
export class EditBookComponent {
  selectedFile: File | null = null;
  book:Book=new Book();
  bookText:string|null='';
  editedBook:Book=new Book();
  edited:boolean=true;
  
  editBookForm:FormGroup;
  constructor(private bookService:BookService,private http: HttpClient,private router:Router){
    this.editBookForm = new FormGroup({
      bookId: new FormControl(""),
      isbn: new FormControl("",[Validators.required,Validators.pattern("[0-9]+")]),
      title: new FormControl("",[Validators.required]),
      author: new FormControl("",[Validators.required]),
      year: new FormControl("",[Validators.required]),
      price: new FormControl("",[Validators.required]),
      seller: new FormControl("",[Validators.required]),
      description: new FormControl("",[Validators.required]),
      imageLocation: new FormControl("",[Validators.required])
    })
  }

  ngOnInit(): void {
    // this.bookText = sessionStorage.getItem('editableBook');
    // if(this.bookText){
    // this.book=JSON.parse(this.bookText);
    const state = history.state;
    if (state && state.book) {
      this.book = state.book; // Set the book to the one passed in

      // Populate the form with the book details
      this.editBookForm.patchValue({
        bookId: this.book.bookId,
        isbn: this.book.isbn,
        title: this.book.title,
        author: this.book.author,
        year: this.book.year,
        price: this.book.price,
        seller: this.book.seller,
        description: this.book.description,
        imageLocation: this.book.imageLocation
      });
    }
  }
  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
  }
  editBook(book:any):void{
    if (this.selectedFile) {
      const formData = new FormData();
      const fileExtension = this.selectedFile.name.split('.').pop();
      const newFileName = `${this.book.isbn}.${fileExtension}`;
      console.log('assets/books/'+newFileName);
      this.book.imageLocation='assets/books/'+newFileName;
      formData.append('image', this.selectedFile, newFileName);
      this.http.post('http://localhost:3000/upload', formData).subscribe(
        (response) => {
          alert("Image uploaded");
        },
        (error) => {
          alert("Image upload Failed");
        }
      );
    }
    
    this.bookService.editBook(book).subscribe((b)=>this.editedBook=b);
    this.edited=false; 
  }
  

}
