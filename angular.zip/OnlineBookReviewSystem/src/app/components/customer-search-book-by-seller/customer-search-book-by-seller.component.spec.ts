import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerSearchBookBySellerComponent } from './customer-search-book-by-seller.component';

describe('CustomerSearchBookBySellerComponent', () => {
  let component: CustomerSearchBookBySellerComponent;
  let fixture: ComponentFixture<CustomerSearchBookBySellerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerSearchBookBySellerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomerSearchBookBySellerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
