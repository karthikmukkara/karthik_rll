import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerBookNavigationComponent } from './customer-book-navigation.component';

describe('CustomerBookNavigationComponent', () => {
  let component: CustomerBookNavigationComponent;
  let fixture: ComponentFixture<CustomerBookNavigationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerBookNavigationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomerBookNavigationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
