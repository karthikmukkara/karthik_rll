import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/service/authentication.service';

@Component({
  selector: 'app-admin-navigation',
  templateUrl: './admin-navigation.component.html',
  styleUrls: ['./admin-navigation.component.css']
})
export class AdminNavigationComponent {
  logout() {
    this.serv.logout();
  }
  loggedin: boolean=true;
   
    constructor(private router:Router,private serv:AuthenticationService){}
  login() {
    this.router.navigate(['/login']);
  }
  ngOnInit(): void {
    if(sessionStorage.getItem('username')!=null ){
      this.loggedin=false;
    }
}
}
