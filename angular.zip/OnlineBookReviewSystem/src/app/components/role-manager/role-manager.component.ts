import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-role-manager',
  templateUrl: './role-manager.component.html',
  styleUrls: ['./role-manager.component.css']
})
export class RoleManagerComponent {
  constructor(private router:Router){}
  ngOnInit(): void {
    let temp:string |  null = sessionStorage.getItem('token');
    if(temp===null || temp.localeCompare('customer')===0){
      this.router.navigate(['/home']);
    }
    if(temp!=null && temp.localeCompare('admin')===0){
      this.router.navigate(['/admin']);
    }
    
  }

}
