import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminIndividualViewBookComponent } from './admin-individual-view-book.component';

describe('AdminIndividualViewBookComponent', () => {
  let component: AdminIndividualViewBookComponent;
  let fixture: ComponentFixture<AdminIndividualViewBookComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminIndividualViewBookComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminIndividualViewBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
