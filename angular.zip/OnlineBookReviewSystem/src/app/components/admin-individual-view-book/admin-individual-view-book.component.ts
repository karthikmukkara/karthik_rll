import { Component } from '@angular/core';
import { Book } from 'src/app/entity/Book';
import { Review } from 'src/app/entity/Review';
import { BookService } from 'src/app/service/book.service';

@Component({
  selector: 'app-admin-individual-view-book',
  templateUrl: './admin-individual-view-book.component.html',
  styleUrls: ['./admin-individual-view-book.component.css']
})
export class AdminIndividualViewBookComponent {

showLike: boolean=false;

deleteComment(bookId: number,commentId: number,userId: number) {
this.bookService.removeComment(userId,bookId,commentId).subscribe((a)=>this.book=a);
}
    
    showComment: boolean=false;
    constructor(private bookService:BookService){}
    hidereview:boolean=true;
    hideComment:boolean=true;
    book:Book=new Book();
    reviews:Review[] = [];
    showReview: boolean = false;
    
    rating:number=0;
    
    ngOnInit(): void {
      
      let str:string|null=sessionStorage.getItem('adminViewBook');
      if(str){
        this.book=JSON.parse(str);
        this.bookService.getBookById(this.book.bookId).subscribe((a)=>{this.book=a;   });
      }
      for(let i =0 ;i<this.book.reviewList.length;i++){
        this.rating+=this.book.reviewList[i].rating;
      }
      this.rating=this.rating/this.book.reviewList.length;
    }
  
    isLiked: boolean = false;
        isCommentVisible: boolean = false;
     

     
        toggleComment() {
            this.isCommentVisible = !this.isCommentVisible;
        }
     
        
        

    showComments() {
this.showComment=!this.showComment;
this.hideComment=!this.hideComment;
    }
     
    showLikes() {
      this.showLike=!this.showLike;
      
      }
     showReviews() {
       this.showReview = !this.showReviews;
       if(this.hidereview){
        this.hidereview=false;
      }
      else{
        this.hidereview=true;
      }
     }
     deleteReview(bookId: number,reviewId:number,custId:number) {
      
      this.bookService.deleteReview(bookId,reviewId,custId).subscribe((a)=>{this.book=a;
        location.reload();
      });
      }

       
     
}
