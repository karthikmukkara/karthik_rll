import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Admin } from 'src/app/entity/Admin';
import { AuthenticationService } from 'src/app/service/authentication.service';

@Component({
  selector: 'app-signup-admin',
  templateUrl: './signup-admin.component.html',
  styleUrls: ['./signup-admin.component.css']
})
export class SignupAdminComponent {
  adminForm: FormGroup;
  addedAdmin:Admin=new Admin();
  constructor(private service: AuthenticationService) {
    this.adminForm = new FormGroup({
        name: new FormControl("", [Validators.required]),
        email: new FormControl("", [Validators.required, Validators.pattern("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$")]),
        password: new FormControl("",
            [Validators.required,
             Validators.pattern("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=])[A-Za-z\\d@#$%^&+=]{8,}$")
            ]),
    });
}
signup(admin: any): void {
  if (this.adminForm.valid) {
    console.log("Admin: " + admin.name);
    this.service.addAdmin(admin).subscribe(
      (response: any) => {
        this.addedAdmin = response;
        console.log("Admin name: " + this.addedAdmin.email);
        alert("Account created successfully");
      },
      (error: any) => {
        console.error("Error occurred during signup:", error);
        alert("An error occurred. Please try again.");
      }
    );
  }
}
}
