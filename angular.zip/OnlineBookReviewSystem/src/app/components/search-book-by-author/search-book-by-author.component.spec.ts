import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchBookByAuthorComponent } from './search-book-by-author.component';

describe('SearchBookByAuthorComponent', () => {
  let component: SearchBookByAuthorComponent;
  let fixture: ComponentFixture<SearchBookByAuthorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchBookByAuthorComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SearchBookByAuthorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
