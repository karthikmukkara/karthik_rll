import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Book } from 'src/app/entity/Book';
import { BookService } from 'src/app/service/book.service';

@Component({
  selector: 'app-add-book',
  templateUrl: './add-book.component.html',
  styleUrls: ['./add-book.component.css']
})
export class AddBookComponent {
  selectedFile: File | null = null;
  book:Book=new Book();
  addedBook:Book=new Book();
  added:boolean=true;
  addBookForm:FormGroup;
  constructor(private bookService:BookService,private http: HttpClient){
    this.addBookForm = new FormGroup({
      isbn: new FormControl("",[Validators.required,Validators.pattern("[0-9]+")]),
      title: new FormControl("",[Validators.required]),
      author: new FormControl("",[Validators.required]),
      year: new FormControl("",[Validators.required]),
      price: new FormControl("",[Validators.required]),
      seller: new FormControl("",[Validators.required]),
      description: new FormControl("",[Validators.required]),
      imageLocation: new FormControl("",[Validators.required])
    })
  }
  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
  }

  addBook(book:any):void{
    this.book.author=book.author;
    this.book.isbn=book.isbn;
    this.book.title=book.title;
    this.book.year=book.year;
    this.book.price=book.price;
    this.book.seller=book.seller;
    this.book.description=book.description;
    
    
    if (this.selectedFile) {
      const formData = new FormData();
      const fileExtension = this.selectedFile.name.split('.').pop();
      const newFileName = `${this.book.isbn}.${fileExtension}`;
      console.log('assets/books/'+newFileName);
      this.book.imageLocation='assets/books/'+newFileName;
      formData.append('image', this.selectedFile, newFileName);
      this.http.post('http://localhost:3000/upload', formData).subscribe(
        (response) => {
          alert("Image uploaded");
        },
        (error) => {
          alert("Image upload failed");
        }
      );
    }
    
    //this.bookService.addBook(this.book).subscribe((b)=>this.addedBook=b);
    this.bookService.addBook(this.book).subscribe((b)=>this.addedBook=b);
    this.added=false; 
  }
}
