import { Component } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-admin-book-navigation',
  templateUrl: './admin-book-navigation.component.html',
  styleUrls: ['./admin-book-navigation.component.css']
})
export class AdminBookNavigationComponent {
  statusForSearch:boolean=true;
  statusForAdd:boolean=false;
  statusForSearchBookByTitle:boolean=false;
  statusForSearchBookByAuthor:boolean=false;
  statusForSearchBookBySeller:boolean=false;
  statusForSearchBookByYear:boolean=false;
statusForView:boolean =false;
  constructor(private route:Router){
 
  }
  add():void{
    
    if(this.statusForAdd){
      this.statusForAdd=false;

    }
    else{
      this.statusForSearchBookByAuthor=false;
      this.statusForSearchBookByTitle=false;
      this.statusForSearchBookBySeller=false;
      this.statusForSearchBookByYear=false; 
      this.statusForAdd=true;
      this.statusForView=false;
    }
  }
  search():void{
    if(this.statusForSearch){
      this.statusForSearch=false;
    }
    else{
      this.statusForSearch=true;
      
    }

    // this.statusForSearch=false;
}
  searchBookByTitle(){
    if(this.statusForSearchBookByTitle){
      this.statusForSearchBookByTitle=false;
    }
    else{
      this.statusForSearchBookByTitle=true;
      this.statusForSearchBookByAuthor=false;
      
      this.statusForSearchBookBySeller=false;
      this.statusForSearchBookByYear=false; 
      this.statusForAdd=false;
      this.statusForView=false;
    }
    
  }
  searchBookByAuthor(){
    if(this.statusForSearchBookByAuthor){
      this.statusForSearchBookByAuthor=false;
    }
    else{
      this.statusForSearchBookByAuthor=true;

      this.statusForSearchBookByTitle=false;
      this.statusForSearchBookBySeller=false;
      this.statusForSearchBookByYear=false; 
      this.statusForAdd=false;
      this.statusForView=false;
    }
  }
  searchBookBySeller(){
    if(this.statusForSearchBookBySeller){
      this.statusForSearchBookBySeller=false;
    }else{
      this.statusForSearchBookByAuthor=false;
      this.statusForSearchBookByTitle=false;
      this.statusForSearchBookBySeller=true;
      this.statusForSearchBookByYear=false; 
      this.statusForAdd=false;
      this.statusForView=false;
    }
  }
  searchBookByYear(){
    if(this.statusForSearchBookByYear){
      this.statusForSearchBookByYear=false;
    }else{
      this.statusForSearchBookByAuthor=false;
      this.statusForSearchBookByTitle=false;
      this.statusForSearchBookBySeller=false;
      this.statusForSearchBookByYear=true;
      this.statusForView=false; 
      this.statusForAdd=false;
    }
  }

  view(){
    if(this.statusForView){
      this.statusForView=false;
    }
    else{
      this.statusForView=true;
      this.statusForSearchBookByTitle=false;
      this.statusForSearchBookByAuthor=false;
      
      this.statusForSearchBookBySeller=false;
      this.statusForSearchBookByYear=false; 
      this.statusForAdd=false;
    }
  }
ngOnInit(): void {
  //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
  //Add 'implements OnInit' to the class.
  
}

  


}
