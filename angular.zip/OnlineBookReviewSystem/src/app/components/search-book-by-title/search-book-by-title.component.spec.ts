import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchBookByTitleComponent } from './search-book-by-title.component';

describe('SearchBookByTitleComponent', () => {
  let component: SearchBookByTitleComponent;
  let fixture: ComponentFixture<SearchBookByTitleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchBookByTitleComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SearchBookByTitleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
