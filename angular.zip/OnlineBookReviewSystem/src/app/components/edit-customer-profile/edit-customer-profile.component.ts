import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Customer } from 'src/app/entity/Customer';
import { AuthenticationService } from 'src/app/service/authentication.service';

@Component({
  selector: 'app-edit-customer-profile',
  templateUrl: './edit-customer-profile.component.html',
  styleUrls: ['./edit-customer-profile.component.css']
})
export class EditCustomerProfileComponent {
  profileUpdated = false;
  isFormDisabled = false;
  showPasswordFields: boolean = false;
  emailIdDisable:boolean=true;
  passwordForm:FormGroup;
  currentPassword:string='';
  newPassword:string='';
  reNewPassword:string='';
  customer:Customer=new Customer();

  
  constructor(private router:Router,private auth:AuthenticationService){
    this.passwordForm=new FormGroup({
      userName:new FormControl(this.customer.name),
      currentPassword: new FormControl("",[Validators.required,Validators.pattern("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=])[A-Za-z\\d@#$%^&+=]{8,}$")]),
      newPassword:new FormControl("",[Validators.required,Validators.pattern("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=])[A-Za-z\\d@#$%^&+=]{8,}$")]),
      reEnteredNewPassword:new FormControl("",[Validators.required,Validators.pattern("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=])[A-Za-z\\d@#$%^&+=]{8,}$")])
    });
  }
 
 
  togglePasswordFields() {
    this.showPasswordFields = !this.showPasswordFields; // Toggle the visibility
  }
  back():void{
    this.router.navigate(['/customerprofile']);
 
  }
 
  updateProfile() {
    
    // this.profileUpdated = true;
    // this.isFormDisabled = true;
    // this.passwordForm.value.userName
    if(this.passwordForm.value.currentPassword.localeCompare(this.customer.password)==0 && this.passwordForm.value.reEnteredNewPassword.localeCompare(this.passwordForm.value.newPassword)==0){
      this.customer.name=this.passwordForm.value.userName;
      this.customer.password=this.passwordForm.value.newPassword;
      this.auth.update(this.customer).subscribe(()=>{
        this.profileUpdated = true;
      this.isFormDisabled = true;
        
      });
    }
    else{
      console.log("jkfdjkdhgkjhfgjkdah klf");
      console.log("current password "+this.passwordForm.value.currentPassword);
      console.log("new password "+this.passwordForm.value.newPassword);
      console.log("re new password "+this.passwordForm.value.reEnteredNewPassword);
    }
 
    setTimeout(() => {
        this.profileUpdated = false;
    }, 3000); 

  }
  ngOnInit(): void {
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.
    let cust:string|null=sessionStorage.getItem("CustomerAccountObject");
    if(cust){
       this.customer=JSON.parse(cust);
    }
  }
}
