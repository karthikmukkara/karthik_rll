import { Component } from '@angular/core';
import { Book } from 'src/app/entity/Book';
import { BookService } from 'src/app/service/book.service';
import { SearchBookService } from 'src/app/service/search-book.service';

@Component({
  selector: 'app-customer-search-book-by-author',
  templateUrl: './customer-search-book-by-author.component.html',
  styleUrls: ['./customer-search-book-by-author.component.css']
})
export class CustomerSearchBookByAuthorComponent {
  bookList:Book[]=[];
  search:number=0;
  author:string='';
  statusForEdit: boolean=false;
  statusForView: boolean=false;
  constructor(private bookService:BookService,private searchBookService:SearchBookService){}
  allBook:Book[]=[];
  suggestion:Book[]=[];
 
  getBooks(){
    this.bookService.getAllEnabledBooks().subscribe((allbooks)=>{
      this.allBook=allbooks;
    });
  }
  onKeyUp(event: KeyboardEvent): void {
    const inputValue = (event.target as HTMLInputElement).value.toLowerCase();
    if (inputValue) {
      this.suggestion=this.allBook.filter(book =>
        book.author.toLowerCase().startsWith(inputValue)
      );
 
    }
    else {
      this.suggestion = [];
    }
  }

  searchBookByAuthor():void{
    
    if(this.author){
      this.searchBookService.searchBookByAuthor(this.author).subscribe(
        (b) => {
            if (b && b.length > 0) {
                this.bookList = b;  
                this.statusForView=true;
                //this.search = 1;  
            } else {
                this.bookList = [];  
                //this.search = 2;                    
            }
        });
  }
    else{
      alert("Please Enter Book Author");
    }
  }

viewBook(book: Book) {
  this.statusForEdit=true;
  this.statusForView=false;
  sessionStorage.setItem('viewBook', JSON.stringify(book));
  
}
  


  ngOnInit(){
    this.getBooks();
  }



}
