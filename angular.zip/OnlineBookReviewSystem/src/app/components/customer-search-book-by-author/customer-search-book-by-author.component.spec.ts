import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerSearchBookByAuthorComponent } from './customer-search-book-by-author.component';

describe('CustomerSearchBookByAuthorComponent', () => {
  let component: CustomerSearchBookByAuthorComponent;
  let fixture: ComponentFixture<CustomerSearchBookByAuthorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerSearchBookByAuthorComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomerSearchBookByAuthorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
