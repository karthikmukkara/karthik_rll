import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Book } from 'src/app/entity/Book';
import { DashboardData } from 'src/app/entity/DashboardData';
import { DashboardServiceService } from 'src/app/service/dashboard-service.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})

export class AdminComponent {
  allBook:Book[]=[];
  hidden:boolean=true;
  maxLikedBook:Book[]=[];
  maxCommentedBook:Book[]=[];
  maxReviewedBook:Book[]=[];
  avgLikesCount:number=0;
  likesCount:number=0;
  commentsCount:number=0;
  totalBooks:number=0;
  dash:DashboardData=new DashboardData();
  constructor(private route:Router,private dashboard:DashboardServiceService){}
  ngOnInit(): void { 

    this.dashboard.getAllData().subscribe((obj)=>{
      this.dash=obj;
      // let obj= this.dashBoard;
      this.maxReviewedBook=obj.maxReviewBooks;
      this.maxCommentedBook=obj.maxCommentBooks;
      this.maxLikedBook=obj.maxLikeBooks;
      this.avgLikesCount=obj.averageLikesPerBook;
      this.totalBooks=obj.bookCount;
      this.commentsCount=obj.commentCount;
      this.likesCount=obj.likeCount;
      this.dashboard.getAllBooks().subscribe((sub)=>{this.allBook=sub;});
    });


  }


}
