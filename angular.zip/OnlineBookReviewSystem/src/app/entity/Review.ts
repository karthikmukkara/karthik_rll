import { Customer } from "./Customer";

 
export class Review{
    public reviewId:number=0;
    public reviewText:string='';
    public rating:number=0;
    public customer:Customer=new Customer();
   
}