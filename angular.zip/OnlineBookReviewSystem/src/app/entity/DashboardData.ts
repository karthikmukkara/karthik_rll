import { Book } from "./Book";

export class DashboardData {
    maxReviewBooks!: Book[];
    maxLikeBooks!: Book[];
    maxCommentBooks!: Book[];
    averageLikesPerBook!: number;
    bookCount!: number;
    likeCount!: number;
    commentCount!: number;
  }