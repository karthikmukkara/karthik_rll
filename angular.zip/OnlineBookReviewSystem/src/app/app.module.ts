import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';


import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { NavigationBarComponent } from './components/navigation-bar/navigation-bar.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { AdminComponent } from './components/admin/admin.component';
import { AboutusComponent } from './components/aboutus/aboutus.component';
import { AdminNavigationComponent } from './components/admin-navigation/admin-navigation.component';
import { AddBookComponent } from './components/add-book/add-book.component';
import { RoleManagerComponent } from './components/role-manager/role-manager.component';
import { AdminBookNavigationComponent } from './components/admin-book-navigation/admin-book-navigation.component';
import { AdminViewBookComponent } from './components/admin-view-book/admin-view-book.component';
import { SearchBookByTitleComponent } from './components/search-book-by-title/search-book-by-title.component';
import { SearchBookByAuthorComponent } from './components/search-book-by-author/search-book-by-author.component';
import { SearchBookBySellerComponent } from './components/search-book-by-seller/search-book-by-seller.component';
import { SearchBookByYearComponent } from './components/search-book-by-year/search-book-by-year.component';
import { EditBookComponent } from './components/edit-book/edit-book.component';
import { CustomerBookNavigationComponent } from './components/customer-book-navigation/customer-book-navigation.component';
import { CustomerViewBookComponent } from './components/customer-view-book/customer-view-book.component';
import { CustomerViewIndividualBookComponent } from './components/customer-view-individual-book/customer-view-individual-book.component';
import { BookSortPipe } from './pipes/book-sort.pipe';
import { CustomerSearchBookByAuthorComponent } from './components/customer-search-book-by-author/customer-search-book-by-author.component';
import { CustomerSearchBookBySellerComponent } from './components/customer-search-book-by-seller/customer-search-book-by-seller.component';
import { CustomerSearchBookByYearComponent } from './components/customer-search-book-by-year/customer-search-book-by-year.component';
import { CustomerSearchBookByTitleComponent } from './components/customer-search-book-by-title/customer-search-book-by-title.component';
import { AdminProfileComponent } from './components/admin-profile/admin-profile.component';
import { EditAdminProfileComponent } from './components/edit-admin-profile/edit-admin-profile.component';
import { CustomerProfileComponent } from './components/customer-profile/customer-profile.component';
import { EditCustomerProfileComponent } from './components/edit-customer-profile/edit-customer-profile.component';
import { SignupAdminComponent } from './components/signup-admin/signup-admin.component';
import { SignupCustomerComponent } from './components/signup-customer/signup-customer.component';
import { AdminIndividualViewBookComponent } from './components/admin-individual-view-book/admin-individual-view-book.component';




@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    NavigationBarComponent,
    AdminComponent,
    AboutusComponent,
    AdminNavigationComponent,
    AddBookComponent,
    RoleManagerComponent,
    AdminBookNavigationComponent,
    AdminViewBookComponent,
    SearchBookByTitleComponent,
    SearchBookByAuthorComponent,
    SearchBookBySellerComponent,
    SearchBookByYearComponent,
    EditBookComponent,
    CustomerBookNavigationComponent,
    CustomerViewBookComponent,
    CustomerViewIndividualBookComponent,
    BookSortPipe,
    CustomerSearchBookByAuthorComponent,
    CustomerSearchBookBySellerComponent,
    CustomerSearchBookByYearComponent,
    CustomerSearchBookByTitleComponent,
    AdminProfileComponent,
    EditAdminProfileComponent,
    CustomerProfileComponent,
    EditCustomerProfileComponent,
    SignupAdminComponent,
    SignupCustomerComponent,
    AdminIndividualViewBookComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
