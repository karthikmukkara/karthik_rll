import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { Book } from '../entity/Book';


@Injectable({
  providedIn: 'root'
})
export class BookService {

  URL:string="http://localhost:9090/book";
  constructor(private http:HttpClient) { }
 
  addBook(book:Book):Observable<any>{
    return this.http.post(this.URL+'/add',book);
  }
  editBook(book:Book):Observable<any>{
    return this.http.put<any>(this.URL+'/modify',book);
  }
  getAllBooks(): Observable<any>{
    return this.http.get(this.URL+"/getAll");
   }
   getBookById(bookId: number): Observable<any> {
    const url = `${this.URL}/get/${bookId}`;
    return this.http.get(url);
  }
   getAllEnabledBooks(): Observable<any>{
    return this.http.get(this.URL+"/getenabledbooks");
   }
  deleteBook(bookId:string):Observable<any>{
    return this.http.delete(this.URL+"/remove/"+bookId);
  }
  addLike(userId:string,bookId:string): Observable<any>{
    return this.http.get(this.URL+"/add/like/"+userId+'/'+bookId);
  }
  removeLike(userId:string,bookId:string): Observable<any>{
    return this.http.delete(this.URL+"/remove/like/"+userId+'/'+bookId);
  }
  deleteReview(bookId: number, reviewId: number, userId: number): Observable<any> {
    const url = `${this.URL}/removereview?userId=${userId}&bookId=${bookId}&reviewId=${reviewId}`;
    return this.http.delete(url);
  }

  removeComment(userId: number, bookId: number, commentId: number): Observable<Book> {
    const url = `${this.URL}/remove/comment/${userId}/${bookId}/${commentId}`;
    return this.http.delete<Book>(url);
  }
  addOrUpdateReview(customerId: string, bookId: number, reviewText: string, rating: number): Observable<any> {
    const params = new HttpParams()
      .set('custId', Number.parseInt(customerId))
      .set('bookId', bookId.toString())
      .set('reviewText', reviewText)
      .set('rating', rating.toString());

    return this.http.post(`${this.URL}/addorupdatereview`,{}, { params });
}
addComment(userId: string, bookId: number, commentText: string): Observable<any> {
  const url = `${this.URL}/add/comment/${userId}/${bookId}`;
  const params = new HttpParams().set('comment', commentText);
  return this.http.post<Book>(url, {}, { params });
}
}
