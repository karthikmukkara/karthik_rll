import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SearchBookService {
  URL:string="http://localhost:9090/book";
  constructor(private http:HttpClient) {
 
   }
 
   searchBookByTitle(title:string):Observable<any>{
    return this.http.get<any>(this.URL+'/getbookbytitle/'+title);
   }
 
   searchBookById(bookId:string):Observable<any>{
    return this.http.get<any>(this.URL+'/get/'+bookId);
   }
 
   searchBookByAuthor(author:string):Observable<any>{
    return this.http.get<any>(this.URL+'/getbookbyauthor/'+author);
   }
 
   searchBookByYear(year:string):Observable<any>{
    return this.http.get<any>(this.URL+'/getbookbyyear/'+year);
   }
 
   searchBookBySeller(seller:string):Observable<any>{
    return this.http.get<any>(this.URL+'/getbookbyseller/'+seller);
   }
}
