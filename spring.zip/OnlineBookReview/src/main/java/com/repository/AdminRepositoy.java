package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.entity.Admin;
@Repository
public interface AdminRepositoy extends JpaRepository<Admin, Integer>{
	@Query("SELECT a FROM Admin a WHERE email = :email")
	public Admin findByEmail(@Param("email") String email);
}
