package com.repository;
 
import com.entity.*;
 
import java.util.List;
 
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
@Repository
public interface BookRepository  extends JpaRepository<Book, Integer> {
	@Query("SELECT b FROM Book b WHERE b.title LIKE CONCAT('%', :bookTitle, '%') AND b.enabled=true")
	public List<Book> getBookByTitle(@Param("bookTitle") String title);
	@Query("SELECT b FROM Book b WHERE b.author LIKE CONCAT('%', :bookAuthor, '%') AND b.enabled=true")
	public List<Book> getBookByAuthor(@Param("bookAuthor") String author);
	@Query("SELECT b FROM Book b WHERE b.year =:bookYear AND b.enabled=true")
	public List<Book> getBookByYear(@Param("bookYear") int year);
	@Query("SELECT b FROM Book b WHERE b.seller LIKE CONCAT('%', :bookSeller, '%') AND b.enabled=true")
	public List<Book> getBookBySeller(@Param("bookSeller") String seller);
	
	public List<Book> findByEnabledTrue();
	
    public List<Book> findByEnabledFalse();
	
	@Query("SELECT b FROM Book b WHERE SIZE(b.reviewList) = (SELECT MAX(SIZE(b2.reviewList)) FROM Book b2)")
	public List<Book> getMaxReviewBook();
	@Query("SELECT b FROM Book b WHERE SIZE(b.likes) = (SELECT MAX(SIZE(b2.likes)) FROM Book b2)")
	public List<Book> getMaxLikeBook();
	@Query("SELECT b FROM Book b WHERE SIZE(b.comments) = (SELECT MAX(SIZE(b2.comments)) FROM Book b2)")
	public List<Book> getMaxCommentBook();
	@Query("SELECT AVG(SIZE(b.likes)) FROM Book b")
	public double getAverageLikesPerBook();
//	@Query("SELECT b from Book b WHERE ")
//	public List<Book> findByLikeId(int id);
	
	
}
