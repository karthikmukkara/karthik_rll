package com.entity;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

import com.entity.*;

import jakarta.annotation.Generated;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
@Entity
@Table(name = "likes_tbl")
public class Likes {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int likeId;
	@ManyToOne(cascade = CascadeType.MERGE ,fetch = FetchType.EAGER)
	Customer likedCustomer;
	LocalDateTime time;
	
	public int getLikeId() {
		return likeId;
	}
	public void setLikeId(int likeId) {
		this.likeId = likeId;
	}
	public Customer getLikedCustomer() {
		return likedCustomer;
	}
	public void setLikedCustomer(Customer likedCustomer) {
		this.likedCustomer = likedCustomer;
	}
	public LocalDateTime getTime() {
		return time;
	}
	public void setTime(LocalDateTime time) {
		this.time = time;
	}
	public Likes(int likeId, Customer likedCustomer, LocalDateTime time) {
		super();
		this.likeId = likeId;
		this.likedCustomer = likedCustomer;
		this.time = time;
	}
	public Likes() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public boolean equals(Object o) {
		if (this == o) return true; 
        if (o == null || getClass() != o.getClass()) return false; // Ensure same class type
        
        Likes likes = (Likes) o;
        
        // Compare the relevant fields (likedCustomer and time) for equality
         return this.likeId==likes.getLikeId();
	}
	
}
