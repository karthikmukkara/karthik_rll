package com.entity;

import java.time.DateTimeException;
import java.time.LocalDateTime;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
@Entity
@Table(name = "comments_tbl")
public class Comments {
	@Id
	@Column(name = "comment_Id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int commentId;
	@Column
	String comment;
	@ManyToOne(cascade = CascadeType.MERGE,fetch = FetchType.EAGER)
	Customer customer;
	@Column(name = "comment_time")
	LocalDateTime commentTime;
	
	public Comments() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Comments(int commentId, String comment, Customer customer, LocalDateTime commentTime) {
		super();
		this.commentId = commentId;
		this.comment = comment;
		this.customer = customer;
		this.commentTime = commentTime;
	}

	public int getCommentId() {
		return commentId;
	}

	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public LocalDateTime getCommentTime() {
		return commentTime;
	}

	public void setCommentTime(LocalDateTime commentTime) {
		this.commentTime = commentTime;
	}

	@Override
	public String toString() {
		return "Comments [commentId=" + commentId + ", comment=" + comment + ", customer=" + customer + ", commentTime="
				+ commentTime + "]";
	}
	
	
	
}
