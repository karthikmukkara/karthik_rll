package com.entity;
 
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
 
@Entity
@Table(name = "review_tbl")
public class Review {
 
	@Id
	@Column(name = "review_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	int reviewId;
	String reviewText;
	int rating;
	@ManyToOne(cascade = CascadeType.MERGE,fetch = FetchType.EAGER)
	Customer customer;
	public Review() {
		super();
	}
 
	public Review(int reviewId, String reviewText, int rating, Customer customer) {
		super();
		this.reviewId = reviewId;
		this.reviewText = reviewText;
		this.rating = rating;
		this.customer = customer;
	}
 
	public int getReviewId() {
		return reviewId;
	}
 
	public void setReviewId(int reviewId) {
		this.reviewId = reviewId;
	}
 
	public String getReviewText() {
		return reviewText;
	}
 
	public void setReviewText(String reviewText) {
		this.reviewText = reviewText;
	}
 
	public int getRating() {
		return rating;
	}
 
	public void setRating(int rating) {
		this.rating = rating;
	}
 
	public Customer getCustomer() {
		return customer;
	}
 
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
 
	@Override
	public String toString() {
		return "Review [reviewId=" + reviewId + ", reviewText=" + reviewText + ", rating=" + rating + ", customer="
				+ customer + "]";
	}
 
	
}