package com.entity;

import java.time.LocalDateTime;

public class Authorizer {
	
	
	String token;
	int userId;
	LocalDateTime loggedInTime;
	LocalDateTime ExpireTime;
	public Authorizer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public LocalDateTime getLoggedInTime() {
		return loggedInTime;
	}
	public void setLoggedInTime(LocalDateTime loggedInTime) {
		this.loggedInTime = loggedInTime;
	}
	public LocalDateTime getExpireTime() {
		return ExpireTime;
	}
	public void setExpireTime(LocalDateTime expireTime) {
		ExpireTime = expireTime;
	}
	@Override
	public String toString() {
		return "Authorizer [token=" + token + ", userId=" + userId + ", loggedInTime=" + loggedInTime + ", ExpireTime="
				+ ExpireTime + "]";
	}
	
	
}
