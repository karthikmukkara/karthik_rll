package com.restController;
 
import java.util.List;
 
import org.springframework.beans.factory.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
 
import com.entity.Book;
import com.entity.DashboardData;
import com.service.DashboardService;
@CrossOrigin("*")
@RestController
@RequestMapping("/dashboard")
public class DashboardRestController {
 
    @Autowired
    private DashboardService dashboardService;
 
    @GetMapping("/max-review-books")
    public ResponseEntity<List<Book>> getMaxReviewBooks() {
        List<Book> books = dashboardService.getMaxReviewBook();
        return ResponseEntity.ok(books);
    }
 
    @GetMapping("/max-like-books")
    public ResponseEntity<List<Book>> getMaxLikeBooks() {
        List<Book> books = dashboardService.getMaxLikeBook();
        return ResponseEntity.ok(books);
    }
 
    @GetMapping("/max-comment-books")
    public ResponseEntity<List<Book>> getMaxCommentBooks() {
        List<Book> books = dashboardService.getMaxCommentBook();
        return ResponseEntity.ok(books);
    }
 
    @GetMapping("/average-likes-per-book")
    public ResponseEntity<Double> getAverageLikesPerBook() {
        double averageLikes = dashboardService.getAverageLikesPerBook();
        return ResponseEntity.ok(averageLikes);
    }
 
    @GetMapping("/book-count")
    public ResponseEntity<Integer> getBookCount() {
        int bookCount = dashboardService.getBookCount();
        return ResponseEntity.ok(bookCount);
    }
 
    @GetMapping("/like-count")
    public ResponseEntity<Integer> getLikeCount() {
        int likeCount = dashboardService.getLikeCount();
        return ResponseEntity.ok(likeCount);
    }
 
    @GetMapping("/comment-count")
    public ResponseEntity<Integer> getCommentCount() {
        int commentCount = dashboardService.getCommentCount();
        return ResponseEntity.ok(commentCount);
    }
    @GetMapping("/all-data")
    public ResponseEntity<DashboardData> getAllDashboardData() {
        DashboardData dashboardData = new DashboardData();
        
        // Set values from the service layer
        dashboardData.setMaxReviewBooks(dashboardService.getMaxReviewBook());
        dashboardData.setMaxLikeBooks(dashboardService.getMaxLikeBook());
        dashboardData.setMaxCommentBooks(dashboardService.getMaxCommentBook());
        dashboardData.setAverageLikesPerBook(dashboardService.getAverageLikesPerBook());
        dashboardData.setBookCount(dashboardService.getBookCount());
        dashboardData.setLikeCount(dashboardService.getLikeCount());
        dashboardData.setCommentCount(dashboardService.getCommentCount());
        
        return ResponseEntity.ok(dashboardData);
    }
    
    
    
}